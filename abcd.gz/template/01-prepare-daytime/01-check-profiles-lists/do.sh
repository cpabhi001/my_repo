#!/bin/bash

new_profiles="../profiles_new.list"
old_profiles="../profiles_current.list"
mkdir -p 01-check-profiles-lists/out-log/

if [[ -e $new_profiles && -e $old_profiles ]]; then
        if [[ -s $new_profiles && -s $old_profiles ]]; then
                echo "Lists of profiles are in place" > 01-check-profiles-lists/out-profiles-ok.list
                echo "Profiles to add:" > 01-check-profiles-lists/out-log/profiles-log.txt
                cat $new_profiles >> 01-check-profiles-lists/out-log/profiles-log.txt
                echo "Profiles to delete:" >> 01-check-profiles-lists/out-log/profiles-log.txt
                cat $old_profiles >> 01-check-profiles-lists/out-log/profiles-log.txt
        else echo "List of profiles are empty. Check them" > 01-check-profiles-lists/out-profiles-error.list
        echo "No profiles in the lists" > 01-check-profiles-lists/out-log/profiles-log.txt
        exit 2
        fi
else echo "List of profiles are not exists" > 01-check-profiles-lists/out-profiles-error.list
echo "Lists of profiles are not in the folder" > 01-check-profiles-lists/out-log/profiles-log.txt
exit 3
fi

