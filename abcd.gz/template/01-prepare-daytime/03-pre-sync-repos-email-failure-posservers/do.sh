#!/bin/bash

MAIL_ADDRESS="dlGDCRUS03ISHMUnix@ts.fujitsu.com"

HERE="$(dirname $(readlink -f $0))"
. $HERE/workflows.inc.sh

 # Set a suitable bubble size to ensure we do not saturate the country gateway link.
BUBBLE_SIZE=10

# Determine the platform release we are upgrading to (if specified)
PL="$((for p in $(cat profiles_new.list); do profuse-zonemaster-cmdb show-profile-tags $p|awk '{print $3}'; done)|grep '^profuse.platform.release=[0-9.]*$'|sed -e s/^profuse.platform.release=//)"

# If a platform was specified, temporarily force the platform version
# to the new version in order to make sure the correct data is uploaded.
if [ "$PL" != "" ]; then
  export FORCE_PROFUSE_PLATFORM_RELEASE="$PL"
fi

# this function will run in case of presync fail. Sending an email here.
function presync_fail {
    # the mailserver is not reachable from some zones, so running it via p1ssts01. Not applicable for test envs
    ssh -o StrictHostKeyChecking=no -i /opt/fujitsu/profuse/zonemaster/data/cm/keys/deploy.key deploy@10.239.255.20 "/opt/kazan/scripts/sendmail/sendmail.sh ${MAIL_ADDRESS} Presync_failure ${HOSTNAME}:${HERE}_presync_has_failed"
}

export -f presync_fail

# Sync with 100 kbyte/s bandwidth throttle
run_presync sync-repo-and-images-posserver 100
