#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

# To change "bubble sizes", add these environment variables in front of the command:
# BUBBLE_SIZE=25 BUBBLE_SIZE_PER_SITE=4
# example: BUBBLE_SIZE=10 BUBBLE_SIZE_PER_SITE=5 run_steps "$@"

run_steps "$@"
