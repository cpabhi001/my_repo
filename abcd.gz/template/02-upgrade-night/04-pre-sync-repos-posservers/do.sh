#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

# Determine the platform release we are upgrading to (if specified)
PL="$((for p in $(cat profiles_new.list); do profuse-zonemaster-cmdb show-profile-tags $p|awk '{print $3}'; done)|grep '^profuse.platform.release=[0-9.]*$'|sed -e s/^profuse.platform.release=//)"

# If a platform was specified, temporarily force the platform version
# to the new version in order to make sure the correct data is uploaded.
if [ "$PL" != "" ]; then
  export FORCE_PROFUSE_PLATFORM_RELEASE="$PL"
fi

# Sync with no bandwidth limitation
run_task sync-repo-and-images-posserver
