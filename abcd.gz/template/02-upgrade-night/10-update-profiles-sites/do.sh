#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

do_delete_profiles
do_add_profiles
cmdb_update_files
