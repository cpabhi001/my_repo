#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

run_task reboot-posserver
sleep_seconds 120
