#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

PROFILE_SUFFIX="SER"
RPMNAME="hmposserver"

# skip if extenda is not upgraded
if ( grep EXTENDA-HM${PROFILE_SUFFIX} profiles.list || grep 04-EXTENDA profiles.list ) ; then true
else
  echo -e "\n\nNo ${RPMNAME} in profiles_new.list, skipping\n\n"
  # just create -ok lists
  run_task run-command-posserver "true"
  exit 0
fi

VERSION="$(profuse-zonemaster-cmdb show-profile-tags $( grep EXTENDA-HM${PROFILE_SUFFIX} profiles.list || grep 04-EXTENDA profiles.list ) | grep =$RPMNAME | sed -e 's/^[^=]*=//' | sed -e s/=/-/)"

run_task run-command-posserver "\"[ \\\$(rpm -q $RPMNAME | sed 's/\.noarch//') == $VERSION ]\""
