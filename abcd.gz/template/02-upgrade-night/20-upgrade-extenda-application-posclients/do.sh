#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

# Stagger to avoid race condition in ansible when hitting POS-server for multiple simultaneous tills
STAGGER_DELAY=10

run_task refresh-posclient
