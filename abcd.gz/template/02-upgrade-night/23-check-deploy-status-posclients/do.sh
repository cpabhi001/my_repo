#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

BUBBLE_SIZE=5 BUBBLE_SIZE_PER_SITE=1 run_task check-deploy-status-posclient
