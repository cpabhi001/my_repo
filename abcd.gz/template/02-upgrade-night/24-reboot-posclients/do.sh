#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

# Stagger reboots by a number of seconds to avoid all units deploying at the same time.
STAGGER_DELAY=60

run_task reboot-posclient
echo "Sleeping for 30 seconds"
sleep 30
