#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

let begin_sleep=`date +%s`

sleep_minutes 60

let total_minutes=(`date +%s` - $begin_sleep)/60

for ((i=0; i<=$total_minutes; i++))
 do echo "z" >> out-minutes-ok.list;
done
