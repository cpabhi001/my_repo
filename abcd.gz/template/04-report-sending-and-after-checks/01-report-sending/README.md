# How to created and send rollout report #

## In the settings file fill *Modifyed variables* ##
```bash
export TO=''
export SUBJECT='report'
export BODY='See attached.'
export report_file='report.csv'
```

* *TO* - email should be separated via comma and space. For example: 'ivan@example.com, vasya@example.com'
* *SUBJECT* - Subject of the email
* *BODY* - The body of email.
* *report_file* - name of the report file. It will generated with this name and attached to email.

## Run script *create_and_send_report.sh* ##

* ./create_and_send_report.sh
OR
* bash create_and_send_report.sh

It will start to scripts *measure.sh* - for generating report, and *sendmail.py* - for sending email with report.
This scripts could be run manually also, but first make sure that you filled *settings* file correctly.

