#!/bin/bash

. settings
echo 'Generating report...'
bash measure.sh
if [[ $? -eq 0 ]]; then
  echo "Report $report_file generated"
  echo "Sending report..."
  python sendmail.py
  if [[ $? -eq 0 ]]; then 
    echo "Report send successfully"
    exit 0
  else echo "Some error during sending..."
    exit 1
  fi
else echo "Some errors during report generating..."
  exit 1
fi
