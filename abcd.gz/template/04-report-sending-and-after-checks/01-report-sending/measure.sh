#!/bin/bash

full_time=0
start_time=$(head -n 4 ../../02-upgrade-night/out-runlog.txt | tail -n 1)
prev_time=$(date --date="${start_time}" "+%s")

echo "Step name;Start time;Execution time;Re-run attempts" > $report_file
for i in $(ls -l ../../02-upgrade-night | grep "^d" | awk '{ print $9 }' | grep ^[0-9])
do
        prefix=$(echo $i | awk -F "-" '{ print $NF }')
        fin_time=$(stat -c%Y ../../02-upgrade-night/${i}/out-${prefix}-ok.list | sed 's/\..*//')
        diff_time=$((fin_time-prev_time))
        echo "${i};$(date -d @${prev_time} '+%Y-%m-%d %H:%M:%S');$((diff_time/60));$(find ../../02-upgrade-night/${i} -type d -name "run-*" | wc -l)" >> $report_file
        full_time=$((full_time+diff_time/60))
        prev_time=$fin_time
done
echo "Total time(min);;$full_time" >> $report_file
echo ";Started;Completed" >> $report_file
echo "Stores;$(wc -l < ../../posservers.list);$(ls -l ../../02-upgrade-night | awk '/posserver/ && /validate/ { print $9 }' | tail -n 1 | xargs -I{} wc -l ../../02-upgrade-night/{}/out-posservers-ok.list | awk '{ print $1 }')" >> $report_file
echo "Tills;$(wc -l < ../../posclients.list);$(ls -l ../../02-upgrade-night | awk '/posclient/ && /validate/ { print $9 }' | tail -n 1 | xargs -I{} wc -l ../../02-upgrade-night/{}/out-posclients-ok.list | awk '{ print $1 }')" >> $report_file
echo "Admin PCs;$(wc -l < ../../posadmins.list);$(ls -l ../../02-upgrade-night | awk '/posadmin/ && /validate/ { print $9 }' | tail -n 1 | xargs -I{} wc -l ../../02-upgrade-night/{}/out-posadmins-ok.list | awk '{ print $1 }')" >> $report_file
echo "Stores list:;$(tr -s '\n' ' ' < ../../sites.list)" >> $report_file
