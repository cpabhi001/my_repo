#!/bin/python
"""Send mail with attachments
"""
from __future__ import print_function

import datetime
import os.path
import mimetypes
import smtplib
import socket
import os

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


utcnow = datetime.datetime.utcnow()
utctimestamp = utcnow.strftime('%Y-%m-%d %H:%M:%S (UTC)')

mailgw_port = 25

# Setup from, to, subject, body
message = MIMEMultipart()
message['From'] = os.environ['sender']
message['To'] = os.environ['TO']
message['Subject'] = os.environ['SUBJECT']
message_body = os.environ['BODY']
message_footer = """

--
This is an automated email that can't be responded to.
Please contact HmStore.Operation3@se.fujitsu.com if there are any
questions or issues regarding this email.

"""

message_body += message_footer
message_body = message_body.replace(r'\n', '\n')
message_body = message_body.replace('\n', '\r\n')
message.attach(MIMEText(message_body))

# Setup attachments
attach=os.environ['report_file'].split()
for arg_attachment in attach:
    if (
        not os.path.isfile(arg_attachment) or
        not os.access(arg_attachment, os.R_OK)
    ):
        exit(
             'ERROR: Attachment "{}" is not a valid, '
             'readable and existing file'.format(arg_attachment)
        )

        # Guess the content type based on the file's extension.  Encoding
        # will be ignored, although we should check for simple things like
        # gzip'd or compressed files.
    ctype, encoding = mimetypes.guess_type(arg_attachment)
    if ctype is None or encoding is not None:
        # No guess could be made, or the file is encoded (compressed), so
        # use a generic bag-of-bits type.
        ctype = 'application/octet-stream'
    maintype, subtype = ctype.split('/', 1)

    with open(arg_attachment, 'rb') as fp:
        attachment = MIMEBase(maintype, subtype)
        attachment.set_payload(fp.read())

    encoders.encode_base64(attachment)
    attachment.add_header(
        'Content-Disposition',
        'attachment',
        filename=os.path.basename(arg_attachment)
    )
    message.attach(attachment)

text = message.as_string()

smtp_server = smtplib.SMTP(os.environ['mailgw'], mailgw_port)
smtp_server.sendmail(os.environ['sender'], os.environ['TO'].split(', '), text)
smtp_server.quit()

print ('''
    From: {0}
    To: {1}
    Subject: {2}
    Attachments: {3}
    Mail gateway: {4}
    '''.format(os.environ['sender'], os.environ['TO'], os.environ['SUBJECT'], os.environ['report_file'], os.environ['mailgw'])
)

