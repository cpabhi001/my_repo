#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

run_task servicemode-disable-posclient

echo Sleeping 2 minutes to ensure posclient application has been fully started.
echo
echo -n "Hit enter to proceed sooner... "
read -t 120
true
