#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

SCRIPT=$HERE/extract-backup-from-archive.sh

run_task run-script-posserver $SCRIPT
