#!/bin/bash

# Check if backup exists:
[ -e /opt/backups/db-latest ] && { name=$(cat /opt/backups/db-latest) ; } || { echo "There is no backup found, aborting..." ; exit 1 ; }
# Check if backup dir exists:
if [ -d /opt/backups/db-${name} ] ; then
  # Check if dir isn't empty:
  [ "$(ls -A /opt/backups/db-${name})" ] && { echo "Backup found name 'db-${name}'" ; exit 0 ; } || { echo "Backup dir is empty, aborting" ; exit 1 ; }
else
  # Check if archive is exists:
  [ -e /opt/backups/states/db-${name}.tar.gz ] || { echo "There is no backup, aborting..." ; exit 1 ; }
  # Create backup dir
  mkdir "/opt/backups/db-${name}"
  # Extract backup
  tar -xzf /opt/backups/states/db-${name}.tar.gz -C /opt/backups/db-${name} && { exit 0 ; } || { echo "Something went wrong during extraction, aborting" ; exit 1 ; }
fi
