#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

#grep '04-EXTENDA' ../../profiles_current.list > profiles_to_add.list
#grep '04-EXTENDA' ../../profiles_new.list > profiles_to_delete.list

do_delete_profiles
do_add_profiles
cmdb_update_files
