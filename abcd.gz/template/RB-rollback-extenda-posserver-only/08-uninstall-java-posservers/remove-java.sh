#!/bin/bash

JRES=$(rpm -aq | egrep '^jre.*fcs')
for JRE in $JRES;
do
  echo -n "Removing JRE $JRE..."
  rpm -e $JRE
  if [ "$?" = "0" ]
  then
    echo "done!"
  else
    echo "failed!"
    exit 1
  fi
done

