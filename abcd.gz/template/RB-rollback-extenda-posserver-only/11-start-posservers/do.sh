#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

SCRIPT=$HERE/start-posserver.sh

run_task run-script-posserver $SCRIPT

echo Sleeping 2 minutes to ensure all posserver services has been fully started.
echo
echo -n "Hit enter to proceed sooner... "
read -t 120
true
