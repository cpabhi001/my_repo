#!/bin/bash

# Check inodb log size
size=$(du /opt/extenda/mysql/ib_logfile1 | cut -f1)
# Ensure correcness of my.cnf
if [ ${size} -lt 6000 ] ; then
  # case 1 log size is 5M
  grep -q 'innodb_log_file_size=5M' /etc/my.cnf || { sed -i 's/^innodb_log_file_size=50M$/innodb_log_file_size=5M/g' /etc/my.cnf ; }
else
  # case 2 log sieze is 50M
  grep -q 'innodb_log_file_size=50M' /etc/my.cnf || { sed -i 's/^innodb_log_file_size=5M$/innodb_log_file_size=50/g' /etc/my.cnf ; }
fi
# Starting services
service mysql start || { echo "error during mysql start" ; exit 1 ; }
service storeagent start || { echo "error during storeagent start" ; exit 1 ; }
service posserver start || { echo "error during posserver start" ; exit 1 ; }
