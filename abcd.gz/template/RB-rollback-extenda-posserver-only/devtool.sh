#!/bin/bash
. /opt/fujitsu/profuse/zonemaster/misc/lib/workflows.inc.sh

workflow_devtool "$@"
