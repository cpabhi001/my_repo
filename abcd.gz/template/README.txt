WORKFLOW: upgrade-applications
--------------------------------------

This workflow will perform an upgrade on posservers, and upgrade
any posclient or posadmin units selected.

This workflow CAN NOT be used to upgrade the platform version. In most cases it
requires a platform >=4.2.0 to already be installed, and will only upgrade
any software configured via profiles or other CMDB configuration.
--------------------------------------

The following two files needs to be created before starting:

  profiles_current.list  = Currently active profiles that should be removed
                           during the rollout (one profile per line or
                           multiple, see (*) below)
  profiles_new.list      = New profiles that should be added during the
                           rollout (one profile per line)

The above profiles are different for each country. Copy the correct files
from the 'profiles_lists/<county>' directory.

(*) The profiles_current.list may contain multiple profiles in one row
separated by a "|" with no spaces between, e.g. PROFILE_V1|PROFILE_V2
means that a site can contain either PROFILE_V1 or PROFILE_V2.
The profiles_new.list may NOT contain "|".

Then the following configuration files are needed in the current directory:

  sites.list             = Sites to process. Manually or create_site_list.sh
  posservers.list        = From sites.list + CMDB + create_unit_lists.sh
  posclients.list        = From sites.list + CMDB + create_unit_lists.sh
  posadmins.list         = From sites.list + CMDB + create_unit_lists.sh

--------------------------------------
Rollback workflows

There are three rollback workflows:
* RA-rollback-db-backup-failed
  This workflow is to be run if any step up to and including
  09-backup-db-and-stop-posservers fails.
  The RA workflow doesn't actually change anything, it just verifies versions,
  ensures the services are started again and disables service mode on the
  POS clients.

* RB-rollback-extenda-posserver-only
  This workflow should be run if any step up to and including step 19 has failed, i.e. if the upgrade
  of the extenda posserver failed. If steps after 19 has started and failed, the next
  rollback scenario (RC-rollback-extenda-only) should be used instead, i.e. the
  RB-rollback-extenda-posserver-only should only be used if upgrade of the posserver
  failed and upgrade of posclients/posadmins has not yet been started.
  You will need to copy the appropriate profile lists to the
  RB-rollback-extenda-posserver-only folder, named as follows:
  - profiles_to_add.list
  - profiles_to_delete.list
  A general rule is that ONLY the "EXTENDA" and/or other software profiles should be
  rolled back. HW, PLATFORM, BASE, BRAND, etc should remain as they are, and any issues
  will have to be resolved manually.
  Rollback of a platform upgrade IS NOT SUPPORTED!

* RC-rollback-extenda-only
  This workflow should be run if a step after 19 fails, i.e if upgrade of
  posclients/posadmins has started but failed. It will attempt to roll
  back the Extenda applications to their previous state while leaving the FJ
  platform at the new version.
  You will need to copy the appropriate profile lists to the
  RC-rollback-extenda-only folder, named as follows:
  - profiles_to_add.list
  - profiles_to_delete.list
  A general rule is that ONLY the "EXTENDA" and/or other software profiles should be
  rolled back. HW, PLATFORM, BASE, BRAND, etc should remain as they are, and any issues
  will have to be resolved manually.
  Rollback of a platform upgrade IS NOT SUPPORTED!

--------------------------------------
In some directories there is a subdir named testdev/ which contains alternate
versions of some of the steps which are more appropriate in a development
setting where the posservers and posclients has no data. You can use these
steps by moving them to the parent directory, and moving the original steps
into a new subdirectory called 'skip'. Only do this in non-P1 environments!
